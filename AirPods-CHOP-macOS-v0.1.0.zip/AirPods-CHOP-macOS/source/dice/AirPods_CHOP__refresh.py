def onFrameStart(frame):
    parent().op('CHANNELS').cook(force=True)

def onStart():
    parent().unstore('runtime')
