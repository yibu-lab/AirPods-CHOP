def onFrameStart(frame):
    parent().op('02_SHAKE_AND_SETTLE').cook(force=True)
def onStart():
    parent().unstore('dice_state')
