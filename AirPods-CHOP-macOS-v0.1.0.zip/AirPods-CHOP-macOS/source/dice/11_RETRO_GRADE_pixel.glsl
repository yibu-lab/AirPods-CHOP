out vec4 fragColor;
void main(){
 vec2 uv=vUV.st;
 vec3 c=texture(sTD2DInputs[0],uv).rgb;
 float vign=1.-.45*smoothstep(.22,.7,distance(uv,vec2(.5)));
 float d=mod(floor(gl_FragCoord.x)+mod(floor(gl_FragCoord.y),2.)*2.,4.)/4.-.375;
 c=floor(clamp(c*vign,0.,1.)*40.+d)/40.;
 fragColor=TDOutputSwizzle(vec4(max(c,vec3(0.)),1.));
}