import math,time,random

def onCook(s):
 s.clear();s.numSamples=1;s.isTimeSlice=False
 b=s.parent();now=time.monotonic();v={c.name:float(c[0]) for c in s.inputs[0].chans()};live=v.get('live',0)>0;demo=bool(b.par.Demo)
 st=b.fetch('dice_state',None)
 if st is None:
  st=dict(t=now,lastshake=-100,mode=0,rot=[0,0,0],start=[0,0,0],target=[0,0,0],settle=0,result=0,rounds=0);b.store('dice_state',st)
 dt=min(.05,max(.001,now-st['t']));st['t']=now
 phase=now%8;energy=(.7 if phase<2.5 else 0) if demo else v.get('accel_magnitude',0)
 shaking=(demo or live) and energy>float(b.par.Threshold)
 if shaking:
  st['lastshake']=now;st['mode']=1;st['result']=0
 if st['mode']==1:
  speed=min(2,max(.3,energy))*float(b.par.Gain)
  for k,rate in enumerate([205,287,153]):st['rot'][k]+=rate*speed*dt
  if now-st['lastshake']>float(b.par.Settlewait):
   st['mode']=2;st['settle']=now;st['result']=random.randint(1,6);st['rounds']+=1;st['start']=st['rot'][:]
   x,y={1:(0,0),6:(0,180),3:(0,-90),4:(0,90),2:(90,0),5:(-90,0)}[st['result']]
   # Final rotation is xyz: preserve chosen face by using zero extra Euler offsets.
   target=[x,y,0];st['target']=[t+360*round((r-t)/360) for r,t in zip(st['rot'],target)]
 elif st['mode']==2:
  p=min(1,(now-st['settle'])/1.4);e=p*p*(3-2*p);st['rot']=[a+(z-a)*e for a,z in zip(st['start'],st['target'])]
  if p>=1:st['mode']=3
 elif st['mode']==0:
  st['rot']=[(v.get('pitch_control',0)*.25 if live else 0),(v.get('roll_control',0)*.35 if live else 0),0]
 height=.08*math.sin(now*1.2)
 if st['mode']==1:height+=.12*math.sin(now*16)
 elif st['mode']==2:height+=.2*math.sin((now-st['settle'])*9)*math.exp(-(now-st['settle'])*3)
 values=dict(rx=st['rot'][0],ry=st['rot'][1],rz=st['rot'][2],height=height,energy=energy,live=int(live),demo=int(demo),state=st['mode'],result=st['result'] if st['mode']==3 else 0,rounds=st['rounds'])
 for k,x in values.items():s.appendChan(k)[0]=x
 b.store('dice_state',st)
