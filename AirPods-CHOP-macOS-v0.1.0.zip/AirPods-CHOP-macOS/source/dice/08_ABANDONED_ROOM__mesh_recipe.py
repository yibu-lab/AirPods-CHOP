import math,random

def onCook(s):
 s.clear();s.pointAttribs.create('N');s.pointAttribs.create('Cd')
 kind=s.parent().fetch('kind');rng=random.Random(321)
 def quad(pts,n,col):
  poly=s.appendPoly(4,closed=True,addPoints=True)
  for v,p in zip(poly,pts):v.point.P=p;v.point.N=n;v.point.Cd=(*col,1)
 def col(v):return (v,v*.985,v*.925)
 if kind=='dice':
  # u cross v = outward normal; opposite faces sum to seven.
  faces=[((0,0,1),(1,0,0),(0,1,0),1),((0,0,-1),(-1,0,0),(0,1,0),6),((1,0,0),(0,0,-1),(0,1,0),3),((-1,0,0),(0,0,1),(0,1,0),4),((0,1,0),(1,0,0),(0,0,-1),2),((0,-1,0),(1,0,0),(0,0,1),5)]
  spots={1:[(0,0)],2:[(-.42,.42),(.42,-.42)],3:[(-.42,.42),(0,0),(.42,-.42)],4:[(-.42,-.42),(-.42,.42),(.42,-.42),(.42,.42)],5:[(-.42,-.42),(-.42,.42),(.42,-.42),(.42,.42),(0,0)],6:[(x,y) for x in [-.42,.42] for y in [-.45,0,.45]]}
  N=48
  for normal,u,v,number in faces:
   def pt(a,b):
    p=[normal[k]+u[k]*a+v[k]*b for k in range(3)];q=[max(-.91,min(.91,x)) for x in p];d=[p[k]-q[k] for k in range(3)];l=math.sqrt(sum(x*x for x in d));return tuple(q[k]+d[k]/l*.09 for k in range(3))
   for j in range(N):
    for i in range(N):
     a=-1+2*i/N;b=-1+2*j/N;cx=a+1/N;cy=b+1/N
     pip=any((cx-x)**2+(cy-y)**2<.145**2 for x,y in spots[number])
     stain=.05*math.sin(cx*21+number)*math.sin(cy*13)+.04*math.sin(cx*7+cy*9)
     c=.035+rng.random()*.025 if pip else .66+stain+rng.uniform(-.055,.055)
     quad([pt(a,b),pt(a+2/N,b),pt(a+2/N,b+2/N),pt(a,b+2/N)],normal,col(c))
 elif kind=='floor':
  N=100
  for j in range(N):
   for i in range(N):
    x=-7+14*i/N;z=-7+14*j/N;d=14/N
    tile=(math.floor(x)+math.floor(z))%2
    v=(.21 if tile else .095)+rng.uniform(-.025,.025)
    # Baked soft contact shadow and distant darkness, intentionally retro.
    shadow=1-.85*math.exp(-((x/1.0)**2+(z/.8)**2)*1.8)
    fade=max(.06,min(1,(z+7)/6))
    v*=shadow*fade
    quad([(x,-1.8,z),(x,-1.8,z+d),(x+d,-1.8,z+d),(x+d,-1.8,z)],(0,1,0),col(v))
 elif kind=='room':
  for wall in range(3):
   for j in range(48):
    for i in range(80):
     a=-7+i*14/80;y=-1.8+j*7/48;da=14/80;dy=7/48
     if wall==0 and abs(a)<.95 and y<1.65:continue
     v=.12+rng.uniform(-.04,.04)+.02*math.sin(i*1.3)*math.sin(j*.4)
     v*=.45 if wall==0 else .7
     if j<3:v*=.5
     if wall==0:pts=[(a,y,-7),(a+da,y,-7),(a+da,y+dy,-7),(a,y+dy,-7)];n=(0,0,1)
     elif wall==1:pts=[(-7,y,a),(-7,y,a+da),(-7,y+dy,a+da),(-7,y+dy,a)];n=(1,0,0)
     else:pts=[(7,y,a+da),(7,y,a),(7,y+dy,a),(7,y+dy,a+da)];n=(-1,0,0)
     quad(pts if wall==0 else list(reversed(pts)),n,col(v))
