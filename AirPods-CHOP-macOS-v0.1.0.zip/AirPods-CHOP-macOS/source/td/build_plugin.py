import os
REPO=AIRPODS_REPO
OUT=os.path.join(REPO,'plugin')
os.makedirs(OUT,exist_ok=True)
b=op('/project1').create(baseCOMP,'AirPods_CHOP')
b.nodeX=1100;b.nodeY=-500
p=b.appendCustomPage('AirPods')
for name,label,default in [('Active','Enable input',True),('Zeroonloss','Zero motion when stale',True),('Recenter','Recenter angles (toggle once)',False)]:p.appendToggle(name,label=label)[0].val=default
for name,label,default in [('Port','OSC port',9010),('Timeout','Stale timeout (seconds)',1),('Anglegain','Angle control gain',1),('Motiongain','Acceleration control gain',1)]:
    par=(p.appendInt(name,label=label) if name=='Port' else p.appendFloat(name,label=label))[0];par.val=default
raw=b.create(oscinCHOP,'OSC_RECEIVER');raw.par.port.expr='parent().par.Port';raw.par.active.expr='parent().par.Active';raw.nodeX=0;raw.nodeY=0
cb=b.create(textDAT,'channel_callbacks');cb.text=open(os.path.join(REPO,'source','td','channels.py')).read();cb.nodeX=200;cb.nodeY=-150
s=b.create(scriptCHOP,'CHANNELS');s.par.callbacks='channel_callbacks';s.inputConnectors[0].connect(raw);s.nodeX=200;s.nodeY=0
out=b.create(outCHOP,'OUT_AIRPODS');out.inputConnectors[0].connect(s);out.nodeX=450;out.nodeY=0
ex=b.create(executeDAT,'refresh');ex.par.framestart=True;ex.par.start=True
ex.text="def onFrameStart(frame):\n    parent().op('CHANNELS').cook(force=True)\n\ndef onStart():\n    parent().unstore('runtime')\n"
ex.nodeX=0;ex.nodeY=-150
readme=b.create(textDAT,'HELP');readme.text='''AIRPODS CHOP v1 — one independent motion source
Run AirPodsBridge.app and Start sensor. UDP localhost 9010.
Connect this component output to Select CHOP; select roll_deg, vertical, etc.
Raw acceleration: g. Raw pitch/roll/yaw: radians. rx/ry/rz: rad/s.
qx/qy/qz/qw: quaternion. gx/gy/gz: gravity in g.
*_deg: degrees. *_relative_deg: wrapped per-axis angle offset.
Recenter affects relative/control angles only, not raw quaternion.
live: 1 when fresh; 0 when stale. age_seconds: time since last new tick.
extended_data: 1 if gravity, rotation and quaternion channels received.
One receiver per port; reuse this output via Select CHOP in other networks.
No simulated input is enabled in this component.
Core Motion data collection still requires the Mac helper and permission.
''';readme.nodeX=450;readme.nodeY=-150
s.cook(force=True)
b.unstore('runtime')
b.save(OUT+'/AirPods_CHOP.tox')
open(OUT+'/validation.txt','w').write('Errors: '+b.errors(recurse=True)+'\nChannels: '+str([c.name for c in s.chans()]))
print('Saved AirPods_CHOP.tox')
