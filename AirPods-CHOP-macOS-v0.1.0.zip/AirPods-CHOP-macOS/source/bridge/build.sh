#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../.."
APP="$PWD/app/AirPodsBridge.app"
mkdir -p "$APP/Contents/MacOS"
cp source/bridge/Info.plist "$APP/Contents/Info.plist"
mkdir -p .build/module-cache
xcrun swiftc -module-cache-path "$PWD/.build/module-cache" source/bridge/Bridge.swift -O -target arm64-apple-macos14.0 -framework Cocoa -framework CoreMotion -framework Network -o "$APP/Contents/MacOS/AirPodsBridge"
codesign --force --sign - "$APP"
printf 'Built: %s\n' "$APP"
