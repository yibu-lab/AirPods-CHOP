# AirPods CHOP · macOS

将兼容 AirPods 的运动数据变成 TouchDesigner CHOP 通道。
提供姿态、加速度、角速度、四元数和连接状态，共 33 个通道。

![骰子示例](examples/preview.png)

## 下载与使用

从本仓库 **Releases** 下载完整 ZIP，解压后：

1. AirPods 连接 Mac 并戴好。
2. 打开 `app/AirPodsBridge.app`，点击 **Start sensor**；首次使用允许运动数据访问。
3. 把 `plugin/AirPods_CHOP.tox` 拖入 TD，保持时间线播放。
4. 确认 `live = 1`，再用 Select CHOP 选择需要的通道。

示例：`AirPods_CHOP → Select (roll_deg) → Lag → 旋转参数`。

要看骰子效果，请在**空白 TD 工程**中拖入 `examples/AirPods_Dice.tox`，进入组件，右键 `17_FINAL → View`。示例已含接收组件，不要再重复添加插件。关闭 Demo 为真实输入，开启 Demo 可离线预览。

## 系统与限制

- 本包是 **Mac / Apple Silicon（M 系列）版**，不是 Windows 或 Intel Mac 安装包。
- 助手编译目标为 macOS 14+；只在开发者当前 Mac 环境实测，未完成各旧系统版本验证。
- TD 组件使用 TouchDesigner 2025.33230 制作。
- 需要支持耳机运动数据的 AirPods；型号与固件差异需实际验证。
- 以佩戴场景使用；离耳后可能停止输出。
- 单一运动数据流，不能把左右耳当两个独立手柄，也不提供绝对空间位置。
- 助手只发送到本机 UDP 9010，不上传数据。同端口只放一个接收组件。
- 助手为本地临时签名，未经 Apple 公证；下载后可能被 macOS 拦截。仅在信任源码时按系统正常安全流程打开，或从源码构建。不需要关闭系统安全保护。

## 包含文件

| 路径 | 用途 |
|---|---|
| `app/` | Mac 采集助手 |
| `plugin/` | 可编辑的 TD 插件 |
| `examples/` | 可编辑的骰子示例与预览 |
| `source/bridge/` | Swift 源码和构建脚本 |
| `source/td/` | 通道处理源码和插件构建脚本 |
| `source/dice/` | 从最终示例导出的 Python / GLSL / DAT 源码 |
| `docs/` | 通道表、示例说明、开发说明 |

完整节点网络保存在可编辑的 `.tox` 中，无锁定组件。示例模型和旧化颜色由程序生成，无第三方图片或模型依赖。骰子点数由程序随机选择，不是物理碰撞结果；当前没有音效。

[通道与参数](docs/CHANNELS.zh-CN.md) · [骰子用法](docs/DICE.zh-CN.md) · [源码构建](docs/DEVELOPMENT.md)

## 开源许可

MIT，见 [LICENSE](LICENSE)。这是独立项目，与 Apple、Derivative 无隶属关系。
