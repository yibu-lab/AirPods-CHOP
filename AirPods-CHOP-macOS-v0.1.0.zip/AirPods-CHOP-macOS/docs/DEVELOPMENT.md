# 从源码构建

## Mac 助手

安装 Apple Command Line Tools，在仓库根目录运行：

```sh
bash source/bridge/build.sh
```

输出 `app/AirPodsBridge.app`。默认 arm64、macOS 14 编译目标，本地临时签名，非开发者证书签名或 Apple 公证。

## TD 插件

`.tox` 已含完整可编辑节点与代码。要重新生成插件，在 TD Textport 执行：

```python
AIRPODS_REPO = '/你的路径/AirPods-CHOP-macOS'
exec(open(AIRPODS_REPO + '/source/td/build_plugin.py').read())
```

建议使用空白工程，避免重复绑定 UDP 9010。生成的组件保存在 `plugin/`。

## 骰子示例

拖入 `examples/AirPods_Dice.tox` 后可以直接编辑节点、参数与 DAT。`source/dice/` 是最终示例中的 DAT 源文副本，文件名里的双下划线表示组件层级；它不是独立运行的 Python 应用。完整场景和参数以 `.tox` 为准。

模型内部使用 Script SOP 生成网格，颜色与材质旧化也是程序生成。画面使用 320×240 渲染，再放大至 960×720。

## 发布

把解压后的内容上传到 GitHub 仓库根目录（README.md 应在根目录）。另外将原 ZIP 作为 Release 附件上传，供观众完整下载；这样也能保留 app 内的可执行权限。
